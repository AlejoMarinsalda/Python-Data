# Python-Data
Repositorio con ejercicios de data en python
En este ejercicio consumi la api de Legue of Legends
luego extraje todos los datos sobre mi cuenta que me parecian importantes
ademas guarde la informacion extraida en diferentes carpetas
el siguiente paso seria analizar esa informacion

el paso por paso documentado se encuentra en el codigo
